function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesLoginLoginPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n<ion-grid class=\"grid-login\">\n  <ion-row>\n    <ion-col align=\"center\">\n      <img src=\"../assets/icon/Fatture logo.png\">\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <form [formGroup]=\"list\" class=\"form-login\" (ngSubmit)=\"login()\">\n        <h3 class=\"name\">Login</h3>\n        <ion-item class=\"item-login\" lines=\"none\">\n          <ion-input type=\"text\" placeholder=\"E-mail\" formControlName=\"email\"></ion-input>\n        </ion-item>\n        <h3 class=\"name\">Senha</h3>\n        <ion-item class=\"item-login\" lines=\"none\">\n          <ion-input (keyup.enter)=\"login()\" type=\"password\" placeholder=\"Senha\" formControlName=\"password\"></ion-input>\n        </ion-item>\n        <ion-button color=\"warning\" type=\"submit\" style=\"text-transform: none;\" class=\"button-login\" [disabled]=\"list.invalid\">\n          Acessar</ion-button>\n      </form>\n    </ion-col>\n\n  </ion-row>\n\n  <ion-row>\n    <ion-col>\n      <span class=\"span-link\" style=\"margin-left:10px;float: right; margin-bottom: -5px; \" align=\"right\" >Esqueci minha\n        senha</span>\n    </ion-col>\n  </ion-row>\n\n\n</ion-grid>\n</ion-content>\n<ion-footer class=\"span-footer\" align=\"center\">\nNão tem uma conta?\n<span class=\"span-link\" >Cadastre-se</span>\n</ion-footer>\n";
    /***/
  },

  /***/
  "./src/app/pages/login/login-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/login/login-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: LoginPageRoutingModule */

  /***/
  function srcAppPagesLoginLoginRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function () {
      return LoginPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./login.page */
    "./src/app/pages/login/login.page.ts");

    var routes = [{
      path: '',
      component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }];

    var LoginPageRoutingModule = function LoginPageRoutingModule() {
      _classCallCheck(this, LoginPageRoutingModule);
    };

    LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], LoginPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/login/login.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/pages/login/login.module.ts ***!
    \*********************************************/

  /*! exports provided: LoginPageModule */

  /***/
  function srcAppPagesLoginLoginModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPageModule", function () {
      return LoginPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./login-routing.module */
    "./src/app/pages/login/login-routing.module.ts");
    /* harmony import */


    var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./login.page */
    "./src/app/pages/login/login.page.ts");

    var LoginPageModule = function LoginPageModule() {
      _classCallCheck(this, LoginPageModule);
    };

    LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]],
      declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })], LoginPageModule);
    /***/
  },

  /***/
  "./src/app/pages/login/login.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/pages/login/login.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesLoginLoginPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".grid-login {\n  margin-top: 8rem;\n  padding: 10px;\n}\n\n.form-login {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  align-content: center;\n  width: 100%;\n}\n\n.button-login {\n  --box-shadow: none;\n  --border: none;\n  --border-radius: 13px;\n  margin-top: 15px;\n  height: 45px;\n  width: 30%;\n  font-weight: normal;\n  font-size: 16px;\n  margin-right: 60%;\n}\n\n.item-login {\n  width: 90%;\n  border: 2px solid #f6891f;\n  border-radius: 5px;\n  margin-bottom: 10px;\n}\n\nion-item {\n  --highlight-color-focused: none;\n}\n\n.div-login-social {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  align-content: spa;\n  padding: 10px;\n  margin-top: 1rem;\n}\n\n.button-login-social {\n  width: 95%;\n}\n\n.div-login-social-content {\n  display: flex;\n  flex-direction: column;\n  align-items: normal;\n  width: 100%;\n}\n\n.icon-login-social {\n  margin-top: -7px;\n  position: absolute;\n  font-size: 32px;\n  color: white;\n}\n\n.line-vertical-login-social {\n  height: 45px;\n  position: absolute;\n  margin-left: 40px;\n  margin-top: -15px;\n}\n\n.line-vertical-login-social-facebook {\n  border-right: 2px solid #2f4c88;\n}\n\n.line-vertical-login-social-google {\n  border-right: 2px solid #c73e2b;\n}\n\n.span-login-social-google {\n  margin-left: -13px;\n}\n\n.span-link {\n  border-bottom: 0px solid black;\n  text-decoration: none;\n  color: #FFCC00;\n}\n\n.span-footer {\n  padding: 10px !important;\n}\n\n.name {\n  color: grey;\n  margin-right: 70%;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbG9naW4vQzpcXFVzZXJzXFxWaWN0b1xcRmF0dHVyZV9wbGFjZS9zcmNcXGFwcFxccGFnZXNcXGxvZ2luXFxsb2dpbi5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFnQjtFQUNoQixhQUFhO0FDQ2pCOztBREVFO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixtQkFBbUI7RUFDbkIscUJBQXFCO0VBQ3JCLFdBQVc7QUNDZjs7QURFRTtFQUNFLGtCQUFhO0VBQ2IsY0FBUztFQUNULHFCQUFnQjtFQUNoQixnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLFVBQVU7RUFDVixtQkFBbUI7RUFDbkIsZUFBZTtFQUNmLGlCQUFpQjtBQ0NyQjs7QURFRTtFQUNFLFVBQVU7RUFDVix5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLG1CQUFtQjtBQ0N2Qjs7QURFRTtFQUNFLCtCQUEwQjtBQ0M5Qjs7QURFRTtFQUNFLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixhQUFhO0VBQ2IsZ0JBQWdCO0FDQ3BCOztBREdFO0VBQ0UsVUFBVTtBQ0FkOztBREVFO0VBQ0UsYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixtQkFBbUI7RUFDbkIsV0FBVztBQ0NmOztBREVFO0VBQ0UsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixlQUFlO0VBQ2YsWUFBWTtBQ0NoQjs7QURFRTtFQUNFLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLGlCQUFpQjtBQ0NyQjs7QURFRTtFQUNFLCtCQUF3QztBQ0M1Qzs7QURFRTtFQUNFLCtCQUF3QztBQ0M1Qzs7QURFRTtFQUNFLGtCQUFrQjtBQ0N0Qjs7QURFRTtFQUNFLDhCQUE4QjtFQUM5QixxQkFBcUI7RUFDckIsY0FFRjtBQ0RGOztBRElFO0VBQ0Usd0JBQXdCO0FDRDVCOztBRElFO0VBQ0ksV0FBVztFQUNYLGlCQUFpQjtBQ0R2QiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ncmlkLWxvZ2luIHtcclxuICAgIG1hcmdpbi10b3A6IDhyZW07XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gIH1cclxuICBcclxuICAuZm9ybS1sb2dpbiB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9XHJcbiAgXHJcbiAgLmJ1dHRvbi1sb2dpbiB7XHJcbiAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAtLWJvcmRlcjogbm9uZTtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogMTNweDtcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICB3aWR0aDogMzAlO1xyXG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIG1hcmdpbi1yaWdodDogNjAlO1xyXG4gIH1cclxuICBcclxuICAuaXRlbS1sb2dpbiB7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgI2Y2ODkxZjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1pdGVtIHtcclxuICAgIC0taGlnaGxpZ2h0LWNvbG9yLWZvY3VzZWQ6IG5vbmU7XHJcbiAgfVxyXG4gIFxyXG4gIC5kaXYtbG9naW4tc29jaWFsIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGFsaWduLWNvbnRlbnQ6IHNwYTtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxcmVtO1xyXG4gIFxyXG4gIH1cclxuICBcclxuICAuYnV0dG9uLWxvZ2luLXNvY2lhbCB7XHJcbiAgICB3aWR0aDogOTUlO1xyXG4gIH1cclxuICAuZGl2LWxvZ2luLXNvY2lhbC1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IG5vcm1hbDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICBcclxuICAuaWNvbi1sb2dpbi1zb2NpYWwge1xyXG4gICAgbWFyZ2luLXRvcDogLTdweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGZvbnQtc2l6ZTogMzJweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgXHJcbiAgLmxpbmUtdmVydGljYWwtbG9naW4tc29jaWFsIHtcclxuICAgIGhlaWdodDogNDVweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIG1hcmdpbi1sZWZ0OiA0MHB4O1xyXG4gICAgbWFyZ2luLXRvcDogLTE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5saW5lLXZlcnRpY2FsLWxvZ2luLXNvY2lhbC1mYWNlYm9vayB7XHJcbiAgICBib3JkZXItcmlnaHQ6IDJweCBzb2xpZCByZ2IoNDcsIDc2LCAxMzYpO1xyXG4gIH1cclxuICBcclxuICAubGluZS12ZXJ0aWNhbC1sb2dpbi1zb2NpYWwtZ29vZ2xlIHtcclxuICAgIGJvcmRlci1yaWdodDogMnB4IHNvbGlkIHJnYigxOTksIDYyLCA0Myk7XHJcbiAgfVxyXG4gIFxyXG4gIC5zcGFuLWxvZ2luLXNvY2lhbC1nb29nbGUge1xyXG4gICAgbWFyZ2luLWxlZnQ6IC0xM3B4O1xyXG4gIH1cclxuICBcclxuICAuc3Bhbi1saW5rIHtcclxuICAgIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCBibGFjaztcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGNvbG9yOiNGRkNDMDBcclxuICBcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgLnNwYW4tZm9vdGVye1xyXG4gICAgcGFkZGluZzogMTBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICAubmFtZXtcclxuICAgICAgY29sb3I6IGdyZXk7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogNzAlO1xyXG4gIH0iLCIuZ3JpZC1sb2dpbiB7XG4gIG1hcmdpbi10b3A6IDhyZW07XG4gIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5mb3JtLWxvZ2luIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmJ1dHRvbi1sb2dpbiB7XG4gIC0tYm94LXNoYWRvdzogbm9uZTtcbiAgLS1ib3JkZXI6IG5vbmU7XG4gIC0tYm9yZGVyLXJhZGl1czogMTNweDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgaGVpZ2h0OiA0NXB4O1xuICB3aWR0aDogMzAlO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi1yaWdodDogNjAlO1xufVxuXG4uaXRlbS1sb2dpbiB7XG4gIHdpZHRoOiA5MCU7XG4gIGJvcmRlcjogMnB4IHNvbGlkICNmNjg5MWY7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWhpZ2hsaWdodC1jb2xvci1mb2N1c2VkOiBub25lO1xufVxuXG4uZGl2LWxvZ2luLXNvY2lhbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGFsaWduLWNvbnRlbnQ6IHNwYTtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luLXRvcDogMXJlbTtcbn1cblxuLmJ1dHRvbi1sb2dpbi1zb2NpYWwge1xuICB3aWR0aDogOTUlO1xufVxuXG4uZGl2LWxvZ2luLXNvY2lhbC1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IG5vcm1hbDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5pY29uLWxvZ2luLXNvY2lhbCB7XG4gIG1hcmdpbi10b3A6IC03cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgZm9udC1zaXplOiAzMnB4O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5saW5lLXZlcnRpY2FsLWxvZ2luLXNvY2lhbCB7XG4gIGhlaWdodDogNDVweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBtYXJnaW4tbGVmdDogNDBweDtcbiAgbWFyZ2luLXRvcDogLTE1cHg7XG59XG5cbi5saW5lLXZlcnRpY2FsLWxvZ2luLXNvY2lhbC1mYWNlYm9vayB7XG4gIGJvcmRlci1yaWdodDogMnB4IHNvbGlkICMyZjRjODg7XG59XG5cbi5saW5lLXZlcnRpY2FsLWxvZ2luLXNvY2lhbC1nb29nbGUge1xuICBib3JkZXItcmlnaHQ6IDJweCBzb2xpZCAjYzczZTJiO1xufVxuXG4uc3Bhbi1sb2dpbi1zb2NpYWwtZ29vZ2xlIHtcbiAgbWFyZ2luLWxlZnQ6IC0xM3B4O1xufVxuXG4uc3Bhbi1saW5rIHtcbiAgYm9yZGVyLWJvdHRvbTogMHB4IHNvbGlkIGJsYWNrO1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIGNvbG9yOiAjRkZDQzAwO1xufVxuXG4uc3Bhbi1mb290ZXIge1xuICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5uYW1lIHtcbiAgY29sb3I6IGdyZXk7XG4gIG1hcmdpbi1yaWdodDogNzAlO1xufVxuIl19 */";
    /***/
  },

  /***/
  "./src/app/pages/login/login.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/pages/login/login.page.ts ***!
    \*******************************************/

  /*! exports provided: LoginPage */

  /***/
  function srcAppPagesLoginLoginPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPage", function () {
      return LoginPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _services_auth_authService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../services/auth/authService */
    "./src/app/services/auth/authService.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");

    var LoginPage = /*#__PURE__*/function () {
      function LoginPage(fbuilder, authService) {
        _classCallCheck(this, LoginPage);

        this.fbuilder = fbuilder;
        this.authService = authService;
      }

      _createClass(LoginPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.list = this.fbuilder.group({
            email: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].pattern(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i)])],
            password: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(5)])]
          });
        }
      }, {
        key: "login",
        value: function login() {
          if (this.list.valid) {
            this.authService.login(this.list.get("email").value, this.list.get("password").value);
          }
        }
      }]);

      return LoginPage;
    }();

    LoginPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
      }, {
        type: _services_auth_authService__WEBPACK_IMPORTED_MODULE_1__["AuthService"]
      }];
    };

    LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-login',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./login.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./login.page.scss */
      "./src/app/pages/login/login.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _services_auth_authService__WEBPACK_IMPORTED_MODULE_1__["AuthService"]])], LoginPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-login-login-module-es5.js.map