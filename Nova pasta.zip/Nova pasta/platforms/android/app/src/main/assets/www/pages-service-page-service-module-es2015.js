(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-service-page-service-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/service-page/service.page.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/service-page/service.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header></app-header>\n\n<ion-content>\n  <ion-grid class=\"grid-login\">\n    <ion-row>\n      <ion-col>\n        <h1 class=\"nameh\">Serviços</h1>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n\n        <h3 class=\"name\">Grupo de serviço</h3>\n        <ion-item class=\"item-login\" lines=\"none\">\n          <ion-select (ionChange)=\"getService($event.target.value)\" slot=\"end\" style=\"max-width: none;\">\n            <ion-select-option *ngFor=\"let item of grupos\" value={{item.id}}> {{item.name}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n\n\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col>\n      \n          <p *ngFor=\"let item of services\"  class=\"name\">{{item.name}}</p>\n       <hr class=\"line-separator\" />\n      </ion-col>\n    </ion-row>\n    \n\n  </ion-grid>\n\n\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/service-page/service-routing.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/service-page/service-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: ServicePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicePageRoutingModule", function() { return ServicePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _service_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./service.page */ "./src/app/pages/service-page/service.page.ts");




const routes = [
    {
        path: '',
        component: _service_page__WEBPACK_IMPORTED_MODULE_3__["ServicePage"]
    }
];
let ServicePageRoutingModule = class ServicePageRoutingModule {
};
ServicePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ServicePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/service-page/service.module.ts":
/*!******************************************************!*\
  !*** ./src/app/pages/service-page/service.module.ts ***!
  \******************************************************/
/*! exports provided: ServicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicePageModule", function() { return ServicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _service_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./service-routing.module */ "./src/app/pages/service-page/service-routing.module.ts");
/* harmony import */ var _service_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./service.page */ "./src/app/pages/service-page/service.page.ts");








let ServicePageModule = class ServicePageModule {
};
ServicePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            src_app_components_component_module__WEBPACK_IMPORTED_MODULE_1__["ComponentsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _service_routing_module__WEBPACK_IMPORTED_MODULE_6__["ServicePageRoutingModule"]
        ],
        declarations: [_service_page__WEBPACK_IMPORTED_MODULE_7__["ServicePage"]]
    })
], ServicePageModule);



/***/ }),

/***/ "./src/app/pages/service-page/service.page.scss":
/*!******************************************************!*\
  !*** ./src/app/pages/service-page/service.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item-login {\n  width: 85%;\n  border: 2px solid #f6891f;\n  border-radius: 0px;\n  margin-bottom: 10px;\n  margin-left: 7%;\n}\n\n.name {\n  color: grey;\n  margin-left: 7%;\n}\n\n.nameh {\n  color: #f6891f;\n  margin-left: 7%;\n}\n\n.button-login {\n  --box-shadow: none;\n  --border: none;\n  --border-radius: 13px;\n  --background: #f6891f;\n  margin-top: 15px;\n  height: 45px;\n  width: 40%;\n  font-weight: normal;\n  font-size: 16px;\n  margin-left: 7%;\n}\n\n.trash {\n  position: absolute;\n  font-size: 40px;\n  color: #f6891f;\n  margin-left: 80%;\n  margin-top: -18%;\n}\n\n.line-separator {\n  width: 262px;\n  height: 0px;\n  opacity: 0.2;\n  border: 1px solid #ffcc00;\n  margin-top: 0px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2VydmljZS1wYWdlL0M6XFxVc2Vyc1xcVmljdG9cXEZhdHR1cmVfcGxhY2Uvc3JjXFxhcHBcXHBhZ2VzXFxzZXJ2aWNlLXBhZ2VcXHNlcnZpY2UucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9zZXJ2aWNlLXBhZ2Uvc2VydmljZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxVQUFVO0VBQ1YseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZUFBZTtBQ0NqQjs7QURDQTtFQUNFLFdBQVc7RUFDWCxlQUFlO0FDRWpCOztBREFBO0VBQ0UsY0FBYztFQUNkLGVBQWU7QUNHakI7O0FEREE7RUFDRSxrQkFBYTtFQUNiLGNBQVM7RUFDVCxxQkFBZ0I7RUFDaEIscUJBQWE7RUFDYixnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLFVBQVU7RUFDVixtQkFBbUI7RUFDbkIsZUFBZTtFQUNmLGVBQWU7QUNJakI7O0FERkE7RUFDRSxrQkFBa0I7RUFDbEIsZUFBZ0I7RUFDaEIsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixnQkFBZ0I7QUNLbEI7O0FESEE7RUFDRSxZQUFZO0VBQ1osV0FBVztFQUNYLFlBQVk7RUFDWix5QkFBeUI7RUFDekIsZUFBZTtBQ01qQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NlcnZpY2UtcGFnZS9zZXJ2aWNlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pdGVtLWxvZ2luIHtcclxuICB3aWR0aDogODUlO1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICNmNjg5MWY7XHJcbiAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDclO1xyXG59XHJcbi5uYW1le1xyXG4gIGNvbG9yOiBncmV5O1xyXG4gIG1hcmdpbi1sZWZ0OiA3JTtcclxufVxyXG4ubmFtZWh7XHJcbiAgY29sb3I6ICNmNjg5MWY7XHJcbiAgbWFyZ2luLWxlZnQ6IDclO1xyXG59XHJcbi5idXR0b24tbG9naW4ge1xyXG4gIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAtLWJvcmRlcjogbm9uZTtcclxuICAtLWJvcmRlci1yYWRpdXM6IDEzcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZjY4OTFmO1xyXG4gIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgaGVpZ2h0OiA0NXB4O1xyXG4gIHdpZHRoOiA0MCU7XHJcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDclO1xyXG59XHJcbi50cmFzaHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgZm9udC1zaXplOiAgNDBweDtcclxuICBjb2xvcjogI2Y2ODkxZjtcclxuICBtYXJnaW4tbGVmdDogODAlO1xyXG4gIG1hcmdpbi10b3A6IC0xOCU7XHJcbn1cclxuLmxpbmUtc2VwYXJhdG9yIHtcclxuICB3aWR0aDogMjYycHg7XHJcbiAgaGVpZ2h0OiAwcHg7XHJcbiAgb3BhY2l0eTogMC4yO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmNjMDA7XHJcbiAgbWFyZ2luLXRvcDogMHB4O1xyXG59IiwiLml0ZW0tbG9naW4ge1xuICB3aWR0aDogODUlO1xuICBib3JkZXI6IDJweCBzb2xpZCAjZjY4OTFmO1xuICBib3JkZXItcmFkaXVzOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn1cblxuLm5hbWUge1xuICBjb2xvcjogZ3JleTtcbiAgbWFyZ2luLWxlZnQ6IDclO1xufVxuXG4ubmFtZWgge1xuICBjb2xvcjogI2Y2ODkxZjtcbiAgbWFyZ2luLWxlZnQ6IDclO1xufVxuXG4uYnV0dG9uLWxvZ2luIHtcbiAgLS1ib3gtc2hhZG93OiBub25lO1xuICAtLWJvcmRlcjogbm9uZTtcbiAgLS1ib3JkZXItcmFkaXVzOiAxM3B4O1xuICAtLWJhY2tncm91bmQ6ICNmNjg5MWY7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG4gIGhlaWdodDogNDVweDtcbiAgd2lkdGg6IDQwJTtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBtYXJnaW4tbGVmdDogNyU7XG59XG5cbi50cmFzaCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgZm9udC1zaXplOiA0MHB4O1xuICBjb2xvcjogI2Y2ODkxZjtcbiAgbWFyZ2luLWxlZnQ6IDgwJTtcbiAgbWFyZ2luLXRvcDogLTE4JTtcbn1cblxuLmxpbmUtc2VwYXJhdG9yIHtcbiAgd2lkdGg6IDI2MnB4O1xuICBoZWlnaHQ6IDBweDtcbiAgb3BhY2l0eTogMC4yO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZjYzAwO1xuICBtYXJnaW4tdG9wOiAwcHg7XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/pages/service-page/service.page.ts":
/*!****************************************************!*\
  !*** ./src/app/pages/service-page/service.page.ts ***!
  \****************************************************/
/*! exports provided: ServicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicePage", function() { return ServicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_service_serviceService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/service/serviceService */ "./src/app/services/service/serviceService.ts");



let ServicePage = class ServicePage {
    constructor(serviceService) {
        this.serviceService = serviceService;
    }
    ngOnInit() {
        this.getGrupo();
    }
    getGrupo() {
        this.serviceService.getGrupo().then((x) => {
            this.grupos = x;
        });
    }
    getService(x) {
        console.log(x);
        this.serviceService.getService(x).then((x) => {
            this.services = x;
        });
    }
};
ServicePage.ctorParameters = () => [
    { type: src_app_services_service_serviceService__WEBPACK_IMPORTED_MODULE_2__["ServiceService"] }
];
ServicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-service',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./service.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/service-page/service.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./service.page.scss */ "./src/app/pages/service-page/service.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [src_app_services_service_serviceService__WEBPACK_IMPORTED_MODULE_2__["ServiceService"]])
], ServicePage);



/***/ })

}]);
//# sourceMappingURL=pages-service-page-service-module-es2015.js.map