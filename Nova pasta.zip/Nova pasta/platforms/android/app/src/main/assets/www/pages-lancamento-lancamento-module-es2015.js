(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-lancamento-lancamento-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/lancamento/lancamento.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/lancamento/lancamento.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header></app-header>\n\n<ion-content>\n  <ion-grid class=\"grid-login\">\n    <form [formGroup]=\"formService\" (ngSubmit)=\"setPayment()\">\n      <ion-row>\n        <ion-col>\n          <h1 class=\"nameh\">Lançamento</h1>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col>\n          <h3 class=\"name\">Profissional</h3>\n          <ion-item class=\"item-login\" lines=\"none\">\n            <ion-select slot=\"end\" (ionChange)=\"getGrupo()\" style=\"max-width: none;\">\n              <ion-select-option value=\"0\">Estabelecimento</ion-select-option>\n\n            </ion-select>\n          </ion-item>\n\n          <h3 class=\"name\">Grupo de serviço</h3>\n          <ion-item class=\"item-login\" lines=\"none\">\n            <ion-select formControlName=\"service_group\" (ionChange)=\"getService($event.target.value)\" slot=\"end\" style=\"max-width: none;\">\n              <ion-select-option *ngFor=\"let item of grupos\" value={{item.id}}> {{item.name}}</ion-select-option>\n            </ion-select>\n          </ion-item>\n          <h3 class=\"name\">Serviço</h3>\n          <ion-item class=\"item-login\" lines=\"none\">\n            <ion-select formControlName=\"service\" slot=\"end\" style=\"max-width: none;\">\n              <ion-select-option  *ngFor=\"let item of services\" value={{item.name}}> {{item.name}}</ion-select-option>\n            </ion-select>\n          </ion-item>\n\n          <h3 class=\"name\">Cliente</h3>\n          <ion-item class=\"item-login\" lines=\"none\">\n            <ion-input formControlName=\"client\" type=\"text\"></ion-input>\n          </ion-item>\n          <h3 class=\"name\">Valor</h3>\n          <ion-item class=\"item-login\" lines=\"none\">\n            <ion-input formControlName=\"price\" type=\"number\"></ion-input>\n          </ion-item>\n          <ion-button class=\"button-login\" type=\"submit\" [disabled]=\"!formService.valid\">Confirmar</ion-button>\n        </ion-col>\n\n      </ion-row>\n    </form>\n  </ion-grid>\n\n\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/lancamento/lancamento-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/lancamento/lancamento-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: LancamentoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LancamentoPageRoutingModule", function() { return LancamentoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _lancamento_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lancamento.page */ "./src/app/pages/lancamento/lancamento.page.ts");




const routes = [
    {
        path: '',
        component: _lancamento_page__WEBPACK_IMPORTED_MODULE_3__["LancamentoPage"]
    }
];
let LancamentoPageRoutingModule = class LancamentoPageRoutingModule {
};
LancamentoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LancamentoPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/lancamento/lancamento.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/lancamento/lancamento.module.ts ***!
  \*******************************************************/
/*! exports provided: lancamentoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lancamentoPageModule", function() { return lancamentoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _lancamento_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lancamento-routing.module */ "./src/app/pages/lancamento/lancamento-routing.module.ts");
/* harmony import */ var _lancamento_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./lancamento.page */ "./src/app/pages/lancamento/lancamento.page.ts");
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/component.module */ "./src/app/components/component.module.ts");








let lancamentoPageModule = class lancamentoPageModule {
};
lancamentoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            src_app_components_component_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _lancamento_routing_module__WEBPACK_IMPORTED_MODULE_5__["LancamentoPageRoutingModule"]
        ],
        declarations: [_lancamento_page__WEBPACK_IMPORTED_MODULE_6__["LancamentoPage"]]
    })
], lancamentoPageModule);



/***/ }),

/***/ "./src/app/pages/lancamento/lancamento.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/lancamento/lancamento.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item-login {\n  width: 85%;\n  border: 2px solid #f6891f;\n  border-radius: 0px;\n  margin-bottom: 10px;\n  margin-left: 7%;\n}\n\n.name {\n  color: grey;\n  margin-left: 7%;\n}\n\n.nameh {\n  color: #f6891f;\n  margin-left: 7%;\n}\n\n.button-login {\n  --box-shadow: none;\n  --border: none;\n  --border-radius: 13px;\n  --background: #f6891f;\n  margin-top: 15px;\n  height: 45px;\n  width: 40%;\n  font-weight: normal;\n  font-size: 16px;\n  margin-left: 7%;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbGFuY2FtZW50by9DOlxcVXNlcnNcXFZpY3RvXFxGYXR0dXJlX3BsYWNlL3NyY1xcYXBwXFxwYWdlc1xcbGFuY2FtZW50b1xcbGFuY2FtZW50by5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2xhbmNhbWVudG8vbGFuY2FtZW50by5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxVQUFVO0VBQ1YseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZUFBZTtBQ0NqQjs7QURFQTtFQUNFLFdBQVc7RUFDWCxlQUFlO0FDQ2pCOztBRENBO0VBQ0UsY0FBYztFQUNkLGVBQWU7QUNFakI7O0FEQUE7RUFDRSxrQkFBYTtFQUNiLGNBQVM7RUFDVCxxQkFBZ0I7RUFDaEIscUJBQWE7RUFDYixnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLFVBQVU7RUFDVixtQkFBbUI7RUFDbkIsZUFBZTtFQUNmLGVBQWU7QUNHakIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9sYW5jYW1lbnRvL2xhbmNhbWVudG8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLml0ZW0tbG9naW4ge1xuICB3aWR0aDogODUlO1xuICBib3JkZXI6IDJweCBzb2xpZCAjZjY4OTFmO1xuICBib3JkZXItcmFkaXVzOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbiAgXG59XG4ubmFtZXtcbiAgY29sb3I6IGdyZXk7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn1cbi5uYW1laHtcbiAgY29sb3I6ICNmNjg5MWY7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn1cbi5idXR0b24tbG9naW4ge1xuICAtLWJveC1zaGFkb3c6IG5vbmU7XG4gIC0tYm9yZGVyOiBub25lO1xuICAtLWJvcmRlci1yYWRpdXM6IDEzcHg7XG4gIC0tYmFja2dyb3VuZDogI2Y2ODkxZjtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgaGVpZ2h0OiA0NXB4O1xuICB3aWR0aDogNDAlO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn0iLCIuaXRlbS1sb2dpbiB7XG4gIHdpZHRoOiA4NSU7XG4gIGJvcmRlcjogMnB4IHNvbGlkICNmNjg5MWY7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWxlZnQ6IDclO1xufVxuXG4ubmFtZSB7XG4gIGNvbG9yOiBncmV5O1xuICBtYXJnaW4tbGVmdDogNyU7XG59XG5cbi5uYW1laCB7XG4gIGNvbG9yOiAjZjY4OTFmO1xuICBtYXJnaW4tbGVmdDogNyU7XG59XG5cbi5idXR0b24tbG9naW4ge1xuICAtLWJveC1zaGFkb3c6IG5vbmU7XG4gIC0tYm9yZGVyOiBub25lO1xuICAtLWJvcmRlci1yYWRpdXM6IDEzcHg7XG4gIC0tYmFja2dyb3VuZDogI2Y2ODkxZjtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgaGVpZ2h0OiA0NXB4O1xuICB3aWR0aDogNDAlO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn1cbiJdfQ== */");

/***/ }),

/***/ "./src/app/pages/lancamento/lancamento.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/lancamento/lancamento.page.ts ***!
  \*****************************************************/
/*! exports provided: LancamentoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LancamentoPage", function() { return LancamentoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_service_serviceService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/service/serviceService */ "./src/app/services/service/serviceService.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");





let LancamentoPage = class LancamentoPage {
    constructor(activatedRoute, serviceService, formBuilder) {
        this.activatedRoute = activatedRoute;
        this.serviceService = serviceService;
        this.formBuilder = formBuilder;
        this.formService = this.formBuilder.group({
            'client': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'service_group': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'service': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'price': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])]
        });
    }
    ngOnInit() {
        this.folder = this.activatedRoute.snapshot.paramMap.get('id');
    }
    getGrupo() {
        this.serviceService.getGrupo().then((x) => {
            this.grupos = x;
        });
    }
    getService(x) {
        console.log(x);
        this.serviceService.getService(x).then((x) => {
            this.services = x;
        });
    }
    setPayment() {
        const data = {
            salon_Id: 3,
            client: this.formService.get("client").value,
            service_group: this.formService.get("service_group").value,
            service: this.formService.get("service").value,
            price: this.formService.get("price").value
        };
        this.serviceService.postPayment(data).then((x) => {
            console.log(x);
        });
    }
};
LancamentoPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _services_service_serviceService__WEBPACK_IMPORTED_MODULE_1__["ServiceService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] }
];
LancamentoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-folder',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./lancamento.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/lancamento/lancamento.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./lancamento.page.scss */ "./src/app/pages/lancamento/lancamento.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _services_service_serviceService__WEBPACK_IMPORTED_MODULE_1__["ServiceService"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]])
], LancamentoPage);



/***/ })

}]);
//# sourceMappingURL=pages-lancamento-lancamento-module-es2015.js.map