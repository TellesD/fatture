(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-add-professional-add-professional-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-professional/add-professional.page.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-professional/add-professional.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header></app-header>\n\n<ion-content>\n  <ion-grid class=\"grid-login\"><br>\n    <ion-row>\n      <ion-col>\n        <h1 class=\"nameh\">Adicionar profissional</h1>\n      </ion-col>\n    </ion-row><br>\n    <ion-row>\n      <ion-col>\n\n        <h3 class=\"name\">Email</h3>\n\n\n\n\n        <ion-item class=\"item-login\" lines=\"none\">\n          <ion-input type=\"text\"></ion-input>\n        </ion-item>\n\n        <ion-button class=\"button-login\">Confirmar</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/add-professional/add-professional-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/pages/add-professional/add-professional-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: AddProfessionalPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddProfessionalPageRoutingModule", function() { return AddProfessionalPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _add_professional_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-professional.page */ "./src/app/pages/add-professional/add-professional.page.ts");




const routes = [
    {
        path: '',
        component: _add_professional_page__WEBPACK_IMPORTED_MODULE_3__["AddProfessionalPage"]
    }
];
let AddProfessionalPageRoutingModule = class AddProfessionalPageRoutingModule {
};
AddProfessionalPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddProfessionalPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/add-professional/add-professional.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/add-professional/add-professional.module.ts ***!
  \*******************************************************************/
/*! exports provided: AddProfessionalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddProfessionalPageModule", function() { return AddProfessionalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _components_component_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _add_professional_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-professional-routing.module */ "./src/app/pages/add-professional/add-professional-routing.module.ts");
/* harmony import */ var _add_professional_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./add-professional.page */ "./src/app/pages/add-professional/add-professional.page.ts");








let AddProfessionalPageModule = class AddProfessionalPageModule {
};
AddProfessionalPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _components_component_module__WEBPACK_IMPORTED_MODULE_1__["ComponentsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _add_professional_routing_module__WEBPACK_IMPORTED_MODULE_6__["AddProfessionalPageRoutingModule"]
        ],
        declarations: [_add_professional_page__WEBPACK_IMPORTED_MODULE_7__["AddProfessionalPage"]]
    })
], AddProfessionalPageModule);



/***/ }),

/***/ "./src/app/pages/add-professional/add-professional.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/pages/add-professional/add-professional.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item-login {\n  width: 85%;\n  border: 2px solid #f6891f;\n  border-radius: 0px;\n  margin-bottom: 10px;\n  margin-left: 7%;\n}\n\n.name {\n  color: grey;\n  margin-left: 7%;\n}\n\n.nameh {\n  color: #f6891f;\n  margin-left: 7%;\n}\n\n.button-login {\n  --box-shadow: none;\n  --border: none;\n  --border-radius: 13px;\n  --background: #f6891f;\n  margin-top: 15px;\n  height: 45px;\n  width: 40%;\n  font-weight: normal;\n  font-size: 16px;\n  margin-left: 7%;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRkLXByb2Zlc3Npb25hbC9DOlxcVXNlcnNcXFZpY3RvXFxGYXR0dXJlX3BsYWNlL3NyY1xcYXBwXFxwYWdlc1xcYWRkLXByb2Zlc3Npb25hbFxcYWRkLXByb2Zlc3Npb25hbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2FkZC1wcm9mZXNzaW9uYWwvYWRkLXByb2Zlc3Npb25hbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxVQUFVO0VBQ1YseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZUFBZTtBQ0NqQjs7QURDQTtFQUNFLFdBQVc7RUFDWCxlQUFlO0FDRWpCOztBREFBO0VBQ0UsY0FBYztFQUNkLGVBQWU7QUNHakI7O0FEREE7RUFDRSxrQkFBYTtFQUNiLGNBQVM7RUFDVCxxQkFBZ0I7RUFDaEIscUJBQWE7RUFDYixnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLFVBQVU7RUFDVixtQkFBbUI7RUFDbkIsZUFBZTtFQUNmLGVBQWU7QUNJakIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9hZGQtcHJvZmVzc2lvbmFsL2FkZC1wcm9mZXNzaW9uYWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLml0ZW0tbG9naW4ge1xyXG4gIHdpZHRoOiA4NSU7XHJcbiAgYm9yZGVyOiAycHggc29saWQgI2Y2ODkxZjtcclxuICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBtYXJnaW4tbGVmdDogNyU7XHJcbn1cclxuLm5hbWV7XHJcbiAgY29sb3I6IGdyZXk7XHJcbiAgbWFyZ2luLWxlZnQ6IDclO1xyXG59XHJcbi5uYW1laHtcclxuICBjb2xvcjogI2Y2ODkxZjtcclxuICBtYXJnaW4tbGVmdDogNyU7XHJcbn1cclxuLmJ1dHRvbi1sb2dpbiB7XHJcbiAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gIC0tYm9yZGVyOiBub25lO1xyXG4gIC0tYm9yZGVyLXJhZGl1czogMTNweDtcclxuICAtLWJhY2tncm91bmQ6ICNmNjg5MWY7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxuICBoZWlnaHQ6IDQ1cHg7XHJcbiAgd2lkdGg6IDQwJTtcclxuICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBtYXJnaW4tbGVmdDogNyU7XHJcbn0iLCIuaXRlbS1sb2dpbiB7XG4gIHdpZHRoOiA4NSU7XG4gIGJvcmRlcjogMnB4IHNvbGlkICNmNjg5MWY7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luLWxlZnQ6IDclO1xufVxuXG4ubmFtZSB7XG4gIGNvbG9yOiBncmV5O1xuICBtYXJnaW4tbGVmdDogNyU7XG59XG5cbi5uYW1laCB7XG4gIGNvbG9yOiAjZjY4OTFmO1xuICBtYXJnaW4tbGVmdDogNyU7XG59XG5cbi5idXR0b24tbG9naW4ge1xuICAtLWJveC1zaGFkb3c6IG5vbmU7XG4gIC0tYm9yZGVyOiBub25lO1xuICAtLWJvcmRlci1yYWRpdXM6IDEzcHg7XG4gIC0tYmFja2dyb3VuZDogI2Y2ODkxZjtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgaGVpZ2h0OiA0NXB4O1xuICB3aWR0aDogNDAlO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn1cbiJdfQ== */");

/***/ }),

/***/ "./src/app/pages/add-professional/add-professional.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/add-professional/add-professional.page.ts ***!
  \*****************************************************************/
/*! exports provided: AddProfessionalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddProfessionalPage", function() { return AddProfessionalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let AddProfessionalPage = class AddProfessionalPage {
    constructor() { }
    ngOnInit() {
    }
};
AddProfessionalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-professional',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./add-professional.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-professional/add-professional.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./add-professional.page.scss */ "./src/app/pages/add-professional/add-professional.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
], AddProfessionalPage);



/***/ })

}]);
//# sourceMappingURL=pages-add-professional-add-professional-module-es2015.js.map