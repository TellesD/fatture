function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-cadastrar-grupo-cadastrar-grupo-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.html":
  /*!*******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.html ***!
    \*******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesCadastrarGrupoCadastrarGrupoPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<app-header></app-header>\n\n<ion-content>\n  <ion-grid class=\"grid-login\"><br>\n    <ion-row>\n      <ion-col>\n        <h1 class=\"nameh\">Cadastrar grupo de serviço</h1>\n      </ion-col>\n    </ion-row><br>\n    <ion-row>\n      <ion-col>\n\n        <h3 class=\"name\">Grupo de serviço</h3>\n\n\n\n\n        <ion-item class=\"item-login\" lines=\"none\">\n          <ion-input type=\"text\" [(ngModel)]=\"grupo\"></ion-input>\n        </ion-item>\n\n        <ion-button class=\"button-login\" (click)=\"cadastrar(grupo)\" >Confirmar</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/cadastrar-grupo/cadastrar-grupo-routing.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/pages/cadastrar-grupo/cadastrar-grupo-routing.module.ts ***!
    \*************************************************************************/

  /*! exports provided: CadastrarGrupoPageRoutingModule */

  /***/
  function srcAppPagesCadastrarGrupoCadastrarGrupoRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CadastrarGrupoPageRoutingModule", function () {
      return CadastrarGrupoPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _cadastrar_grupo_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./cadastrar-grupo.page */
    "./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.ts");

    var routes = [{
      path: '',
      component: _cadastrar_grupo_page__WEBPACK_IMPORTED_MODULE_3__["CadastrarGrupoPage"]
    }];

    var CadastrarGrupoPageRoutingModule = function CadastrarGrupoPageRoutingModule() {
      _classCallCheck(this, CadastrarGrupoPageRoutingModule);
    };

    CadastrarGrupoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CadastrarGrupoPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/cadastrar-grupo/cadastrar-grupo.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/cadastrar-grupo/cadastrar-grupo.module.ts ***!
    \*****************************************************************/

  /*! exports provided: CadastrarGrupoPageModule */

  /***/
  function srcAppPagesCadastrarGrupoCadastrarGrupoModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CadastrarGrupoPageModule", function () {
      return CadastrarGrupoPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _components_component_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../components/component.module */
    "./src/app/components/component.module.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _cadastrar_grupo_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./cadastrar-grupo-routing.module */
    "./src/app/pages/cadastrar-grupo/cadastrar-grupo-routing.module.ts");
    /* harmony import */


    var _cadastrar_grupo_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./cadastrar-grupo.page */
    "./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.ts");

    var CadastrarGrupoPageModule = function CadastrarGrupoPageModule() {
      _classCallCheck(this, CadastrarGrupoPageModule);
    };

    CadastrarGrupoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _components_component_module__WEBPACK_IMPORTED_MODULE_1__["ComponentsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _cadastrar_grupo_routing_module__WEBPACK_IMPORTED_MODULE_6__["CadastrarGrupoPageRoutingModule"]],
      declarations: [_cadastrar_grupo_page__WEBPACK_IMPORTED_MODULE_7__["CadastrarGrupoPage"]]
    })], CadastrarGrupoPageModule);
    /***/
  },

  /***/
  "./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.scss":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.scss ***!
    \*****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesCadastrarGrupoCadastrarGrupoPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".item-login {\n  width: 85%;\n  border: 2px solid #f6891f;\n  border-radius: 0px;\n  margin-bottom: 10px;\n  margin-left: 7%;\n}\n\n.name {\n  color: grey;\n  margin-left: 7%;\n}\n\n.nameh {\n  color: #f6891f;\n  margin-left: 7%;\n}\n\n.button-login {\n  --box-shadow: none;\n  --border: none;\n  --border-radius: 13px;\n  --background: #f6891f;\n  margin-top: 15px;\n  height: 45px;\n  width: 40%;\n  font-weight: normal;\n  font-size: 16px;\n  margin-left: 7%;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2FkYXN0cmFyLWdydXBvL0M6XFxVc2Vyc1xcVmljdG9cXEZhdHR1cmVfcGxhY2Uvc3JjXFxhcHBcXHBhZ2VzXFxjYWRhc3RyYXItZ3J1cG9cXGNhZGFzdHJhci1ncnVwby5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2NhZGFzdHJhci1ncnVwby9jYWRhc3RyYXItZ3J1cG8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsVUFBVTtFQUNWLHlCQUF5QjtFQUN6QixrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLGVBQWU7QUNDakI7O0FEQ0E7RUFDRSxXQUFXO0VBQ1gsZUFBZTtBQ0VqQjs7QURBQTtFQUNFLGNBQWM7RUFDZCxlQUFlO0FDR2pCOztBRERBO0VBQ0Usa0JBQWE7RUFDYixjQUFTO0VBQ1QscUJBQWdCO0VBQ2hCLHFCQUFhO0VBQ2IsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixVQUFVO0VBQ1YsbUJBQW1CO0VBQ25CLGVBQWU7RUFDZixlQUFlO0FDSWpCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY2FkYXN0cmFyLWdydXBvL2NhZGFzdHJhci1ncnVwby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaXRlbS1sb2dpbiB7XHJcbiAgd2lkdGg6IDg1JTtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjZjY4OTFmO1xyXG4gIGJvcmRlci1yYWRpdXM6IDBweDtcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiA3JTtcclxufVxyXG4ubmFtZXtcclxuICBjb2xvcjogZ3JleTtcclxuICBtYXJnaW4tbGVmdDogNyU7XHJcbn1cclxuLm5hbWVoe1xyXG4gIGNvbG9yOiAjZjY4OTFmO1xyXG4gIG1hcmdpbi1sZWZ0OiA3JTtcclxufVxyXG4uYnV0dG9uLWxvZ2luIHtcclxuICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgLS1ib3JkZXI6IG5vbmU7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiAxM3B4O1xyXG4gIC0tYmFja2dyb3VuZDogI2Y2ODkxZjtcclxuICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gIGhlaWdodDogNDVweDtcclxuICB3aWR0aDogNDAlO1xyXG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIG1hcmdpbi1sZWZ0OiA3JTtcclxufSIsIi5pdGVtLWxvZ2luIHtcbiAgd2lkdGg6IDg1JTtcbiAgYm9yZGVyOiAycHggc29saWQgI2Y2ODkxZjtcbiAgYm9yZGVyLXJhZGl1czogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogNyU7XG59XG5cbi5uYW1lIHtcbiAgY29sb3I6IGdyZXk7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn1cblxuLm5hbWVoIHtcbiAgY29sb3I6ICNmNjg5MWY7XG4gIG1hcmdpbi1sZWZ0OiA3JTtcbn1cblxuLmJ1dHRvbi1sb2dpbiB7XG4gIC0tYm94LXNoYWRvdzogbm9uZTtcbiAgLS1ib3JkZXI6IG5vbmU7XG4gIC0tYm9yZGVyLXJhZGl1czogMTNweDtcbiAgLS1iYWNrZ3JvdW5kOiAjZjY4OTFmO1xuICBtYXJnaW4tdG9wOiAxNXB4O1xuICBoZWlnaHQ6IDQ1cHg7XG4gIHdpZHRoOiA0MCU7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLWxlZnQ6IDclO1xufVxuIl19 */";
    /***/
  },

  /***/
  "./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.ts ***!
    \***************************************************************/

  /*! exports provided: CadastrarGrupoPage */

  /***/
  function srcAppPagesCadastrarGrupoCadastrarGrupoPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CadastrarGrupoPage", function () {
      return CadastrarGrupoPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _services_service_serviceService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../services/service/serviceService */
    "./src/app/services/service/serviceService.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var CadastrarGrupoPage = /*#__PURE__*/function () {
      function CadastrarGrupoPage(serviceService) {
        _classCallCheck(this, CadastrarGrupoPage);

        this.serviceService = serviceService;
      }

      _createClass(CadastrarGrupoPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "cadastrar",
        value: function cadastrar(x) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.serviceService.postGrupo(x);

                  case 2:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return CadastrarGrupoPage;
    }();

    CadastrarGrupoPage.ctorParameters = function () {
      return [{
        type: _services_service_serviceService__WEBPACK_IMPORTED_MODULE_1__["ServiceService"]
      }];
    };

    CadastrarGrupoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-cadastrar-grupo',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./cadastrar-grupo.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./cadastrar-grupo.page.scss */
      "./src/app/pages/cadastrar-grupo/cadastrar-grupo.page.scss"))["default"]]
    }), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_services_service_serviceService__WEBPACK_IMPORTED_MODULE_1__["ServiceService"]])], CadastrarGrupoPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-cadastrar-grupo-cadastrar-grupo-module-es5.js.map